package com.company.message.utils;

public class Main {
  public static void main(String[] args) {
      String filename = "multi_thread_messages.txt";
      new MessageProcessor().loadAndProcessData(filename);
  }
}
