package com.company.message.utils;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Map;
import java.util.Vector;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Stream;

public class MessageProcessor {
    public void loadAndProcessData(String filename) {
        Map<Character, Vector<Integer>> map = new ConcurrentHashMap<>();
        try (Stream<String> record = Files.lines(Paths.get(filename))) {
            record.forEach(e -> {
                String[] split = e.split("\\|");
                Character id = split[0].charAt(0);
                Integer sleepTime = Integer.valueOf(split[1]);
                map.computeIfAbsent(id, k -> new Vector<>()).add(sleepTime);
            });
            processMessages(map);
        } catch (IOException e) {
            System.out.println(e.getMessage());
            System.exit(1);
        }
    }

    private void processMessages(Map<Character, Vector<Integer>> map) {
        map.values().parallelStream().forEach(e -> e.parallelStream()
                .forEachOrdered(s -> {
                    try {
                        Thread.sleep(s);
                    } catch (InterruptedException ex) {
                        System.out.println(ex.getMessage());
                        System.exit(1);
                    }
                }));
    }
}
