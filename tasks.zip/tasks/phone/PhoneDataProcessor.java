package com.company.phone.utils;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.stream.Stream;

public class PhoneDataProcessor {
    public void processMessages(String fileName){
        try {
          Dictionary dictionary = loadData(file);
          handleSearch(dictionary);
        } catch(Exception e){
          System.out.println(e.getMessage()); // very basic handling
        }
    }

    private void handleSearch(Dictionary dictionary) {
        Scanner in = new Scanner(System.in);
        String searchWord;
        while (true) {
            System.out.print("Enter Name/Area Code: ");
            searchWord = in.nextLine();
            if (searchWord == null || searchWord.trim().length() == 0) {
                System.exit(0);
            }

            if (searchWord.matches("\\d*")) {
                handleAreaCodes(dictionary.getAreaCodes(), searchWord);
            } else {
                handleNames(dictionary, searchWord);
            }
        }
    }

    private void handleNames(Dictionary dictionary, String searchWord) {
        int searchWordLength = searchWord.split("\\s+").length;
        if (searchWordLength == 3) {
            printResult(dictionary.getFullNames(), searchWord, "Number of people whose full name is %s is %d");
        } else if (searchWordLength == 2) {
            printResult(dictionary.getFirstAndLastNames(), searchWord, "Number of people whose name is %s: %d");
        } else if (searchWordLength == 1) {
            Integer firstNameCount = dictionary.getFirstNames().get(searchWord.toLowerCase());
            Integer lastNameCount = dictionary.getLastNames().get(searchWord.toLowerCase());
            if (firstNameCount != null) {
                System.out.println(String.format("Number of people whose first name is %s: %d",
                        searchWord, firstNameCount));
            }

            if (lastNameCount != null) {
                System.out.println(String.format("Number of people whose last name is %s: %d",
                        searchWord, lastNameCount));
            }
        } else {
            System.out.println("Input is wrong");
            System.exit(1);
        }
    }

    private void printResult(Map<String, Integer> fullNames, String searchWord, String s) {
        Integer count = fullNames.get(searchWord.toLowerCase());
        System.out.println(String.format(s,
                searchWord, count == null ? 0 : count));
    }

    private void handleAreaCodes(Map<String, Integer> areaCodes, String searchWord) {
        printResult(areaCodes, searchWord, "Number of people with area code(%s): %d ");
    }

    private Dictionary loadData(String file) {
        Map<String, Integer> firstNames = new HashMap<>();
        Map<String, Integer> firstAndLastNames = new HashMap<>();
        Map<String, Integer> fullNames = new HashMap<>();
        Map<String, Integer> lastNames = new HashMap<>();
        Map<String, Integer> areaCodes = new HashMap<>();

        try (Stream<String> record = Files.lines(Paths.get(file))) {
            record.forEach(e -> {
                String[] split = e.split("\\|");
                String fullName = split[0].toLowerCase();
                String areaCode = split[1].substring(0, 3);
                String[] name = fullName.split("\\s+");
                String firstName = name[0];
                String lastName = name[2];
                firstNames.merge(firstName, 1, Integer::sum);
                firstAndLastNames.merge(firstName + " " + lastName, 1, Integer::sum);
                lastNames.merge(lastName, 1, Integer::sum);
                fullNames.merge(fullName, 1, Integer::sum);
                areaCodes.merge(areaCode, 1, Integer::sum);
            });
        } catch (IOException e) {
            System.out.println(e.getMessage());
            System.exit(1);
        }

        return new Dictionary(firstNames, firstAndLastNames, lastNames, fullNames, areaCodes);
    }
}
