package com.company;

import java.util.HashMap;
import java.util.Map;

public class Dictionary {
    private Map<String, Integer> firstNames = new HashMap<>();
    private Map<String, Integer> firstAndLastNames = new HashMap<>();
    private Map<String, Integer> lastNames = new HashMap<>();
    private Map<String, Integer> fullNames = new HashMap<>();
    private Map<String, Integer> areaCodes = new HashMap<>();

    public Dictionary() {
    }

    public Dictionary(Map<String, Integer> firstNames, Map<String, Integer> firstAndLastNames, Map<String, Integer> lastNames, Map<String, Integer> fullNames, Map<String, Integer> areaCodes) {
        this.firstNames = firstNames;
        this.firstAndLastNames = firstAndLastNames;
        this.lastNames = lastNames;
        this.fullNames = fullNames;
        this.areaCodes = areaCodes;
    }

    public Map<String, Integer> getFirstNames() {
        return firstNames;
    }

    public void setFirstNames(Map<String, Integer> firstNames) {
        this.firstNames = firstNames;
    }

    public Map<String, Integer> getFirstAndLastNames() {
        return firstAndLastNames;
    }

    public void setFirstAndLastNames(Map<String, Integer> firstAndLastNames) {
        this.firstAndLastNames = firstAndLastNames;
    }

    public Map<String, Integer> getLastNames() {
        return lastNames;
    }

    public void setLastNames(Map<String, Integer> lastNames) {
        this.lastNames = lastNames;
    }

    public Map<String, Integer> getFullNames() {
        return fullNames;
    }

    public void setFullNames(Map<String, Integer> fullNames) {
        this.fullNames = fullNames;
    }

    public Map<String, Integer> getAreaCodes() {
        return areaCodes;
    }

    public void setAreaCodes(Map<String, Integer> areaCodes) {
        this.areaCodes = areaCodes;
    }
}
