package com.company.phone.utils;

public class Main {
    public static void main(String[] args) {
        String fileName = "phone_directory.txt";
        new PhoneDataProcessor().processMessages(fileName);
    }
  }
